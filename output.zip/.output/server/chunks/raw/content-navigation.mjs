// ROLLUP_NO_REPLACE 
 const contentNavigation = "[{\"title\":\"Nuxt Content\",\"_path\":\"/component\"},{\"title\":\"Nuxt Content\",\"_path\":\"/markdown\"}]";

export { contentNavigation as default };
