// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/component\":[\"content:component.md\"],\"/markdown\":[\"content:markdown.md\"]}";

export { contentIndex as default };
