import{b4 as e}from"./CS4j3-PT.js";const t=()=>e().$supabase.client;export{t as u};
