import{b2 as s,b3 as e,X as o}from"./_-NCtvQ0.js";const u=s((a,t)=>{if(!e().value)return o("/login")});export{u as default};
