import{br as s}from"./_-NCtvQ0.js";const t=s("/nuxt-logo.svg");export{t as _};
