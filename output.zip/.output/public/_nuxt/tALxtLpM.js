import{bt as s}from"./DCGP32LW.js";const t=s("/nuxt-logo.svg");export{t as _};
