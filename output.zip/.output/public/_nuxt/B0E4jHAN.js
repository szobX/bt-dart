import{b7 as s,b8 as e,X as o}from"./C-uanV9o.js";const u=s((a,t)=>{if(!e().value)return o("/login")});export{u as default};
