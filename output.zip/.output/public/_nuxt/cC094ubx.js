import{b5 as s,b6 as e,X as o}from"./CS4j3-PT.js";const u=s((a,t)=>{if(!e().value)return o("/login")});export{u as default};
