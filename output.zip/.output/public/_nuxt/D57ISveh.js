import{b8 as e}from"./v9OCMSMQ.js";const t=()=>e().$supabase.client;export{t as u};
