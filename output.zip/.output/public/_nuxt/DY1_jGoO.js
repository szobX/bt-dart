import{bu as s}from"./v9OCMSMQ.js";const t=s("/nuxt-logo.svg");export{t as _};
