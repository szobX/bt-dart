import{b9 as s,ba as e,X as a}from"./v9OCMSMQ.js";const u=s((o,t)=>{if(!e().value)return a("/login")});export{u as default};
