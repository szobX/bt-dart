const e={welcome:{t:0,b:{t:2,i:[{t:3}],s:"Willkommen"}},save:{t:0,b:{t:2,i:[{t:3}],s:"Speichern"}},search:{t:0,b:{t:2,i:[{t:3}],s:"Suchen"}}};export{e as default};
