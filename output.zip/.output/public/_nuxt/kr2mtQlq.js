import{bt as s}from"./CS4j3-PT.js";const t=s("/nuxt-logo.svg");export{t as _};
