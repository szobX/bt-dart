const e={welcome:{t:0,b:{t:2,i:[{t:3}],s:"Welcome"}},save:{t:0,b:{t:2,i:[{t:3}],s:"Save"}},search:{t:0,b:{t:2,i:[{t:3}],s:"Search"}}};export{e as default};
