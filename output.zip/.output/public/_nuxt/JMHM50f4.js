import{b6 as e}from"./C-uanV9o.js";const t=()=>e().$supabase.client;export{t as u};
