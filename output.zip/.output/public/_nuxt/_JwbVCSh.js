import{bt as s}from"./C-uanV9o.js";const t=s("/nuxt-logo.svg");export{t as _};
