import{b1 as e}from"./_-NCtvQ0.js";const t=()=>e().$supabase.client;export{t as u};
